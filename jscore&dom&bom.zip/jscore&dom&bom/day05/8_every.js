var arr1=[2,4,6,4,2];
var arr2=[1,2,3,4,5];
                //5 undefined
                //5<=undefined
                //5<=Number(undefined)
                     //NaN
                //5<=NaN false
//判断数组是否全由偶数组成
console.log(
  arr1.every(function(elem){
    return elem%2==0;
  }),
  arr2.every(function(elem){
    return elem%2==0;
  })
);
//判断数组是否升序排列
console.log(
  arr1.every(function(elem,i,arr){
    return i<arr.length-1?elem<=arr[i+1]:true;
  }),
  arr2.every(function(elem,i,arr){
    return i<arr.length-1?elem<=arr[i+1]:true;
  })
);