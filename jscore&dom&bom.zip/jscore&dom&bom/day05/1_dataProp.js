"use strict";
var eric={
  id:1001,
  ename:"埃里克",
  salary:12000
};
var id_attrs=Object.getOwnPropertyDescriptor(eric,"id")
//console.log(id_attrs);
//id禁止修改
//ename禁止删除
//salary禁止遍历
Object.defineProperties(eric,{
  id:{writable:false,configurable:false},
  ename:{configurable:false},
  salary:{enumerable:false,configurable:false}
})

// Object.defineProperty(eric,"id",{
//   writable:true,configurable:true
// })
//eric.id=1002;
//delete eric.ename;
for(var key in eric){
  console.log(key+" : "+eric[key]);
}
console.log(eric.id, eric.ename, eric.salary);

