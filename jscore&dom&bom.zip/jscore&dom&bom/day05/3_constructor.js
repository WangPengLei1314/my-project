"use strict"
function Emp(id,ename,salary,age){
  Object.defineProperties(this,{
    id:{
      value:id,
      writable:false,
      enumerable:true
    },
    ename:{
      value:ename,
      writable:true,
      enumerable:true
    },
    salary:{
      value:salary,
      writable:true,
      enumerable:false
    },
    _age:{
      writable:true,
      enumerable:false
    }
  });
  this.age=age;//将参数age交给爹中的age保镖检查，检查通过，由爹中的age，赋值回this的_age属性中
  //防扩展: 
  //Object.preventExtensions(this);
  //密封:
  Object.seal(this);
}
Object.defineProperty(Emp.prototype,"age",{
  get:function(){ return this._age; },
  set:function(value){
    if(value>=18&&value<=65)
      this._age=value;
    else
      throw new RangeError("年龄必须介于18~65之间");
  },
  enumerable:true,
  configurable:false
});
var eric=new Emp(1001,"埃里克",12000,26);
//id只读，ename禁止删除，薪资禁止遍历，年龄介于18~65之间
//eric.id=1002;
//delete eric.ename;
// for(var key in eric){
//   console.log(key+" : "+eric[key]);
// }
//eric.age=-2;
//eric.Age=-2;
console.log(eric.id, eric.ename, eric.salary, eric.age)
