function calc(base,bonus1,bonus2){
  console.log(this.ename+"的总工资是:"+(base+bonus1+bonus2));
}
var lilei={ename:"Li Lei"};
var hmm={ename:"Han Meimei"};
//临时借用
calc.call(lilei,10000,1000,2000);
var arr=[3000,4000,5000];
calc.apply(hmm,arr);
    //打散arr为单个参数值

//复制副本
var calc_l=calc.bind(lilei,10000);
//calc_l:function calc(10000,bonus1,bonus2){
  //this.ename->lilei.ename
//}
calc_l(1000,2000);
calc_l(2000,3000);
calc_l.call(hmm,3000,4000,5000);