"use strict";
var dbconfig={
  ip:"127.0.0.1",
  port:3306,
  db:"xz",
  user:"root",
  pwd:""
};
Object.freeze(dbconfig);
dbconfig.port=27017;
