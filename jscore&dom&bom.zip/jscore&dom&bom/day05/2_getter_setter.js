var eric={ id:1001, ename:"埃里克", _age:26 };
Object.defineProperties(eric,{
  //修改原有数据属性: 默认值都是true
  _age:{enumerable:false,configurable:false},
  //新添加的: 默认值都是false
  age:{
    get:function(){
      console.log("自动调用eric.age的get()")
      return this._age
    },
    set:function(value){
      console.log("自动调用eric.age的set()")
      if(value>=18&&value<=65)
        this._age=value;
      else 
        throw new RangeError("年龄必须介于18~65之间！")
    },
    enumerable:true,
    configurable:false
  }
})
console.log(eric.age);//自动调get()
eric.age=27;//自动调set() 正常修改
console.log(eric.age);//自动调get()
eric.age=-2;//自动调set() 报错！