var father={ bal:1000000000, car:"infiniti"}
var hmm=Object.create(father,{
  //defineProperties
  bao:{
    value:"LV",
    writable:true,
    enumerable:true,
    configurable:false
  },
  phone:{
    value:"iPhoneX",
    writable:true,
    enumerable:true,
    configurable:false
  }
});
console.log(hmm);
console.log(hmm.__proto__);
console.log(hmm.bal, hmm.car);