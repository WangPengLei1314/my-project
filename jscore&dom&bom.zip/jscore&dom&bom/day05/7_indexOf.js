var arr=[1,2,3,4,3,2,1];
       //0 1 2 3 4 5 6
console.log(
  arr.indexOf(3),//2
  arr.indexOf(3,3),//4
  arr.indexOf(3,5),//-1
  arr.indexOf(5) //-1
);