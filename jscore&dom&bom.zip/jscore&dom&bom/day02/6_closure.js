function outer(){
  var i=0;
  return function(){
    i++;
    console.log(i);
  }
}
var getNum=outer();
//getNum:function(){ i++; console.log(i); }
getNum();
getNum();
i=0;
getNum();
getNum();
getNum=null; //释放闭包