//var a;

console.log(a);//undefined
let a=10;//声明var a; 赋值a=10
console.log(a);//10

var b=10;
function fun(){
  //var b

  console.log(b);//undefined
  let b=100;
  console.log(b);//100
}
fun();
console.log(b);//10