function fun(){
  var n=999;
  nAdd=function(){n++};//强行创建全局变量nAdd
  return function(){
    console.log(n);
  }
}
var get=fun();
//get:function(){ console.log(n); }
get();//999
nAdd();//n=1000
get();//1000

function fn(){
  for(var i=0,arr=[];i<3;i++){
    arr[i]=function(){console.log(i);}
  }
  //i=3
  return arr;
  /*
  [ function, function, function ]
  */
}
var funs=fn();
//funs: [ function, function, function ]
funs[0]();//3
funs[1]();//3
funs[2]();//3