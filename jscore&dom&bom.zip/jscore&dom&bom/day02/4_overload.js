function pay(         ){ 
 //arguments[         ].length
  if(arguments.length==0)
    console.log("手机支付..."); 
  else if(arguments.length==1)
    console.log("现金支付..."); 
  else
    console.log("刷卡支付...");
}

pay();
pay(100);
pay("6551 1234","123456");

//作业: 
function add(){
  
}
console.log(
  add(1,2,3), //6
  add(1,2,3,4,5) //15
);