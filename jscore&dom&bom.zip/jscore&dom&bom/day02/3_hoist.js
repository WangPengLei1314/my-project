//function fun(){ console.log(1) }
//function fun(){ console.log(2) }

//function fun(){ console.log(1) }
var fun=function(){ console.log(1) }
fun();//1
//function fun(){ console.log(2) }
var fun=function(){ console.log(2) }
fun();//2