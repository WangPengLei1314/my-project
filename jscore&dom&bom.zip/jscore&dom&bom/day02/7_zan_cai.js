var zan=(function(){
  var i=0;
  return function(){
    i++;
    console.log("赞+"+i);
  }
})();
var cai=(function(){
  var i=0;
  return function(){
    i++;
    console.log("踩+"+i);
  }
})();

zan();//赞+1
zan();//赞+2
zan();//赞+3
cai();//踩+1
cai();//踩+2