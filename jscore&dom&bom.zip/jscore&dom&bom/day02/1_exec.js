var str="明明喜欢我，却不告诉我。别理我，我想静静。静静是谁？你先告诉我明明是谁？";
var reg=/明明|静静/g;
do{
  var arr=reg.exec(str);
  if(arr!=null)
    console.log("在位置"+arr.index+"发现关键词"+arr[0]);
  else
    break;
}while(true);