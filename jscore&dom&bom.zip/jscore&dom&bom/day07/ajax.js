function ajax(url){
  return new Promise(function(open,err){
    var xhr=new XMLHttpRequest();
    xhr.onreadystatechange=function(){
      if(xhr.readyState==4&&xhr.status==200){
        if(Math.random()<0.5){
          console.log(xhr.responseText);
          open();
        }else{
          err("有人摔倒了!");
        }
      } 
    }
    xhr.open("get",url,true);
    xhr.send(null);
  })
}