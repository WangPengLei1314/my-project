var http=require("http");
http.createServer((req,res)=>{
  res.writeHead(200,{
    "Access-Control-Allow-Origin":"*",
    "Content-Type":"text/html;charset=utf-8"
  });
  var path=decodeURI(req.url);
  if(path=="/成亮")
    setTimeout(function(){ res.end("成亮到达!"); },4000);
  else if(path=="/燕儿")
    setTimeout(function(){ res.end("燕儿到达!"); },6000);
  else if(path="/东东")
    setTimeout(function(){ res.end("东东到达!"); },2000);
  else{ res.writeHead(404); res.end(); }
}).listen(80);