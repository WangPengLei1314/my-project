class User{
  constructor(uname,upwd){
    this.uname=uname;
    this.upwd=upwd;
  }
  save(){ console.log("保存"+this.uname+"成功!"); }
  static getByName(uname){
    return new User(uname,"123456");
  }
}
var eric=User.getByName("埃里克");
console.log(eric);
eric.uname="史密斯";
eric.save();