"use strict"
class Emp{
  constructor(id,ename,salary,age){
    Object.defineProperties(this,{
      id:{
        value:id,
        writable:false,
        enumerable:true
      },
      ename:{
        value:ename,
        writable:true,
        enumerable:true
      },
      salary:{
        value:salary,
        writable:true,
        enumerable:false
      },
      _age:{
        writable:true,
        enumerable:false
      }
    });
    this.age=age;
    Object.seal(this);
  }
  get age(){ return this._age; }
  set age(value){
    if(value>=18&&value<=65)
      this._age=value;
    else
      throw new RangeError("年龄必须介于18~65之间");
  }
}
var eric=new Emp(1001,"埃里克",12000,26);

eric.age=-2;
console.log(eric.id, eric.ename, eric.salary, eric.age)
