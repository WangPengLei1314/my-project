class Student{
  constructor(sname,sage){
    this.sname=sname;
    this.sage=sage;
  }
  intr(){
    console.log("I'm "+this.sname+", I'm "+this.sage);
  }
}
var lilei=new Student("Li Lei",11);
var hmm=new Student("Han Meimei",12);
console.log(lilei);
lilei.intr();
console.log(hmm);
hmm.intr();
console.log(typeof Student);
console.log(lilei.intr==Student.prototype.intr);