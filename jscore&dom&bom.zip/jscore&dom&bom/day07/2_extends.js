class Enemy{
  constructor(fname,speed){
    this.fname=fname; 
    this.speed=speed;
  }
  fly(){
    console.log(this.fname+"以时速"+this.speed+"飞行")
  }
}
class Plane extends Enemy{
  constructor(fname,speed,score){
    super(fname,speed);
    this.score=score;
  }
  getScore(){
    console.log("击落"+this.fname+"得"+this.score+"分")
  }
}
//Object.setPrototypeOf(Plane.prototype, Enemy.prototype)
var f16=new Plane("F16",1000,5);
f16.fly();
f16.getScore();
console.log(f16);