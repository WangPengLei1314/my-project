var a=2;
function Fun(){
  this.a=3
}
Fun.prototype.a=5;
Fun.prototype.getA=function(){
  console.log(this.a);
}
var obj=new Fun();
obj.getA();//3
