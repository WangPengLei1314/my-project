var lilei={
  sname:"Li Lei",
  sage:11,
  intr:function(){
    console.log("I'm "+this.sname+", I'm "+this.sage);
  }
}
function clone(obj){
  var newObj={};
  for(var key in obj){
    //newObj.key=obj[key];
    //newObj["key"]=obj[key];
    newObj[key]=obj[key];
  }
  return newObj;
}
//var lilei_copy=lilei;
var lilei_copy=clone(lilei);
console.log(lilei_copy);
console.log(lilei);
console.log(lilei==lilei_copy);//false
console.log([]==[]);//false