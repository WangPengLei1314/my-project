var n=345.678;
console.log(n.toFixed(2));//345.68
//typeof n  ->  number
//   new Number(n).toFixed(2) -> 345.68
//   new Number释放

var str="Hello";
str.len=10;
//typeof str -> string
 //new String(str).len=10
  //new String释放！
console.log(str.len);//undefined
          //typeof str -> string
          //new String(str).len -> undefined