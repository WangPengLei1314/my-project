//李雷: 11岁
    //会自我介绍: I'm Li Lei, I'm 11
var lilei={
  sname:"Li Lei",
  sage:11,
  intr:function(){
    console.log("I'm "+this.sname+", I'm "+this.sage);
  }
}
var hmm={
  sname:"Han Meimei",
  sage:12,
  intr:function(){
    console.log("I'm "+this.sname+", I'm "+this.sage);
  }
}

console.log(lilei.sage);
lilei.intr();
lilei.sage++;
console.log(lilei.sage);
lilei.intr();

var fun=lilei.intr;
//fun:function(){
    // console.log("I'm "+this.sname+", I'm "+this.sage);
  // }
/*global.*/fun();//undefined    undefined
/*在浏览器中运行*/
var a=10;
var obj={
  a:20,
  fun:function(){
    var a=30;
    console.log(this.a);
  }
}
var f=obj.fun;
obj.fun();//20
/*window.*/f();//10
