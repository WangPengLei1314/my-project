function Enemy(fname,speed){
  //this->global->Plane中的this
  this.fname=fname; 
  this.speed=speed;
}
Enemy.prototype.fly=function(){
  console.log(this.fname+"以时速"+this.speed+"飞行")
}
function Plane(fname,speed,score){
  Enemy.call(this,fname,speed);
  this.score=score;
}
Plane.prototype.getScore=function(){
  console.log("击落"+this.fname+"得"+this.score+"分")
}
Object.setPrototypeOf(Plane.prototype, Enemy.prototype)
var f16=new Plane("F16",1000,5);
f16.fly();
f16.getScore();
console.log(f16);
console.log(global.fname);
console.log(global.speed);