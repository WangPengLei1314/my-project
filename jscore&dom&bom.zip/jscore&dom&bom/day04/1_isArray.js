var obj1={x:1}, obj2=[1,2,3], obj3=new Date();
//1. 判断爹
console.log(
  //obj1.__proto__==Array.prototype,//false
  Array.prototype.isPrototypeOf(obj1),
  //obj2.__proto__==Array.prototype,//true
  Array.prototype.isPrototypeOf(obj2),
  //obj3.__proto__==Array.prototype //false
  Array.prototype.isPrototypeOf(obj3)
);
//2. 判断妈
console.log(
  // obj1.constructor==Array,//false
  obj1 instanceof Array,
      // 实例
  // obj2.constructor==Array,//true
  obj2 instanceof Array,
  // obj3.constructor==Array //false
  obj3 instanceof Array
);
//问题: 
//问题1. 不只检查直接父级，且检查整个原型链
console.log(
  Object.prototype.isPrototypeOf(obj2),//true
  obj2 instanceof Object //true
);
//问题2. __proto__可能被修改
var obj4=new Date();
    obj4.__proto__=Array.prototype;
console.log(
  Array.prototype.isPrototypeOf(obj4), //true
  obj4 instanceof Array //true
);
//3. 判断DNA:class属性
console.log(
  Object.prototype.toString.call(obj1)=="[object Array]",//false
  Object.prototype.toString.call(obj2)=="[object Array]",//true
  Object.prototype.toString.call(obj3)=="[object Array]",//false
  Object.prototype.toString.call(obj4)=="[object Array]" //false
);
//4. ES5中已经新增了isArray()
console.log(
  Array.isArray(obj1),
  Array.isArray(obj2),
  Array.isArray(obj3),
  Array.isArray(obj4)
);//arr.sort()   arr.push()    arr.reverse()...