"use strict";

// a=10;
// console.log(a);
// console.log(global.a);

// var eric={ id:1001, ename:"埃里克" };
// Object.defineProperty(eric,"id",{
//   writable:false
// });
// eric.id=1002;
// console.log(eric);

function Enemy(fname,speed){
  //this->全局->use strict->undefined
  this.fname=fname;
  this.speed=speed;
}
Enemy("F16",1000);
console.log(global.fname, global.speed);
