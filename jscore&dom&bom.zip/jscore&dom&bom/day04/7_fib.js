"use strict"
//f1=1  f2=1    fn=f(n-1)+f(n-2)
function fib(n){
  if(n<3) return 1;
  else{
    var fun=arguments.callee;//代表当前正在调用的函数自己
    return fun(n-1)+fun(n-2);
  }
}
// function fib(n){
//   if(n<3) return 1;
//   else{
//   /*f1   f2    fn
//      1    1     2   i=3
//      1    2     3   i=4
//      2    3     5   i=5
//      3    5     8   i=6*/
//     var f1=1,f2=1,fn;
//     for(var i=3;i<=n;i++){
//       fn=f1+f2;
//       f1=f2;
//       f2=fn;
//     }
//     return fn;
//   }
// }
//1 1 2 3 5 8 13 21 34 55
console.log(fib(10));