//Object.prototype
  //toString() [object Object]

var lilei={
  sname:"Li Lei",
  sage:11,
  toString:function(){
    return "{ sname: "+this.sname+", sage: "+this.sage+"}";
  }
};
console.log(lilei.toString());
