var n=3, s="Hello", b=true, nu=null, un;
var f=function(){}, arr=[], obj={}, date=new Date();
console.log(
  typeof n,
  typeof s,
  typeof b,
  typeof nu,
  typeof un,
  typeof f,
  typeof arr,
  typeof obj,
  typeof date
);