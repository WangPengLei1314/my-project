function Student(sname,sage){
  this.sname=sname;
  this.sage=sage;
}
var father={bal:10000000000,car:"infiniti"};
Student.prototype=father;
Student.prototype.intr=function(){
  console.log("I'm "+this.sname+", I'm "+this.sage);
}
var lilei=new Student("Li Lei",18);
var hmm=new Student("Han Meimei",19);
//Object.setPrototypeOf(hmm, father);
console.log(hmm.bal, hmm.car);
console.log(lilei.bal, lilei.car);