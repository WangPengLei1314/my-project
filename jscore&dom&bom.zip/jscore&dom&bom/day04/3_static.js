function User(id,name){
  this.id=id;
  this.name=name;
}
//按id查找用户——静态成员
User.getById=function(id){
  console.log("查询id为"+id+"的用户");
}
//保存当前用户到数据库——实例成员
User.prototype.save=function(){
  console.log("保存id为"+this.id+"的用户");
}
var eric=new User(1001,"埃里克");
eric.save();
User.getById(1001);
