//查找触发事件的元素
var chbAll=document.querySelector(
  "table>thead>tr>th:first-child>input"
);
//绑定事件
chbAll.onclick=function(){
  var chbAll=this;
  //查找要修改的元素
  var chbs=document.querySelectorAll(
    "table>tbody>tr>td:first-child>input"
  );
  //修改元素
  for(var chb of chbs){
    chb.checked=chbAll.checked;
  }
}

//查找触发事件的元素
var chbs=document.querySelectorAll(
  "table>tbody>tr>td:first-child>input"
);
//绑定事件
for(var chb of chbs){
  chb.onclick=function(){
    var chb=this;
    //查找要修改的元素:chbAll
    //修改元素
    //尝试查找一个未选中的chb
    var checked=document.querySelector(
      "table>tbody>tr>td:first-child>input:not(:checked)"
    );
    if(checked==null)//如果没找到
      chbAll.checked=true;//就全选
    else
      chbAll.checked=false;
  }
}