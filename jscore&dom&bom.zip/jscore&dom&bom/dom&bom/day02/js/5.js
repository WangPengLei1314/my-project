//查找触发事件的元素
var txtName=
  document.getElementsByName("username")[0];
var txtPwd=
  document.getElementsByName("pwd")[0];
//绑定事件
txtName.onfocus=txtPwd.onfocus=function(){
  //查找要修改的元素
  var txt=this;
  var div=txt.parentNode
             .nextElementSibling
             .children[0];
  //修改元素
  txt.className="txt_focus";
  div.className="";
}
txtName.onblur=function(){
  vali(this,/^\w{1,10}$/);
}
function vali(txt,reg){
  //查找要修改的元素
  var div=txt.parentNode
             .nextElementSibling
             .children[0];
  //修改元素
  txt.className="";
  if(reg.test(txt.value))
    div.className="vali_success";
  else
    div.className="vali_fail";
}
txtPwd.onblur=function(){
  vali(this,/^\d{6}$/);
}
  