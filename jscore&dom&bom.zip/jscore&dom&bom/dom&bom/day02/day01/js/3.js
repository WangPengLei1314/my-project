//1. 查找触发事件的元素
var table=document.getElementById("data");
var btns=table.getElementsByTagName("button");
console.log(btns);
//2. 绑定事件
for(var btn of btns){
  btn.onclick=function(){
    var btn=this; //this->当前btn
    //3. 查找要修改的元素
    var span=btn.parentNode.children[1];
    var n=parseFloat(span.innerHTML);
    if(btn.innerHTML=="+")
      n++;
    else if(n>1)
      n--;
    //4. 修改元素
    span.innerHTML=n;

    /*修改小计*/
    var price=parseFloat(
      btn.parentNode //td
         .previousElementSibling //前一个td
         .innerHTML //内容¥XXXX.00
         .slice(1) //去掉¥
    );
    //小计=单价*数量
    var sub=price*n;
    btn.parentNode.nextElementSibling.innerHTML
      =`¥${sub.toFixed(2)}`;

    /*修改总计*/
    //找到每行最后一个td
    var tds=table.querySelectorAll(
      "tbody>tr>td:last-child"
    );
    var total=0;
    for(var td of tds){
      total+=parseFloat(td.innerHTML.slice(1));
    }
    table.querySelector(
      "tfoot>tr>td:last-child"
    ).innerHTML=`¥${total.toFixed(2)}`;
  }
  //btn.onclick();
}
  