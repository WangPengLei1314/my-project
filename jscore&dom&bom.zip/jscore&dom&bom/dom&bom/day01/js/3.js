//1. 查找触发事件的元素
var table=document.getElementById("data");
var btns=table.getElementsByTagName("button");
console.log(btns);
//2. 绑定事件
for(var btn of btns){
  btn.onclick=function(){
    var btn=this; //this->当前btn
    //3. 查找要修改的元素
    var span=btn.parentNode.children[1];
    var n=parseFloat(span.innerHTML);
    if(btn.innerHTML=="+")
      n++;
    else if(n>1)
      n--;
    //4. 修改元素
    span.innerHTML=n;
  }
  //btn.onclick();
}
  