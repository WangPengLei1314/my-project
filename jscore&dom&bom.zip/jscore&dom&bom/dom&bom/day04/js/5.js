var offsetX,offsetY;
var canMove=false;
pop.onmousedown=function(e){
  offsetX=e.offsetX;
  offsetY=e.offsetY;
  canMove=true;
}
window.onmousemove=function(e){
  if(canMove){
    var {clientX,clientY}=e;
    pop.style.left=`${clientX-offsetX}px`;
    pop.style.top=`${clientY-offsetY}px`;
  }
}
pop.onmouseup=function(){
  canMove=false;
}