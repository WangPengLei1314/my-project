var form=document.forms[0];
form.username.onfocus=form.pwd.onfocus=function(){
  var txt=this;
  txt.className="txt_focus";
  var div=txt.parentNode
             .nextElementSibling
             .firstElementChild;
  div.className="";
}
form.username.onblur=function(){
  vali(this,/^\w{1,10}$/);
}
function vali(txt,reg){
  txt.className="";
  var div=txt.parentNode
             .nextElementSibling
             .firstElementChild;
  if(reg.test(txt.value)){
    div.className="vali_success";
    return true;
  }else{
    div.className="vali_fail";
    return false;
  }
}
form.pwd.onblur=function(){
  vali(this,/^\d{6}$/);
}
//查找触发事件的元素
//绑定事件
form.elements[form.length-2].onclick=function(){
  //查找要修改的元素
  //修改元素
  /*var rName=vali(form.username,/^\w{1,10}$/);
  var rPwd=vali(form.pwd,/^\d{6}$/);
  if(rName&&rPwd)
    form.submit();*/
  if(!vali(form.username,/^\w{1,10}$/))
    form.username.focus();
  else if(!vali(form.pwd,/^\d{6}$/))
    form.pwd.focus();
  else
    form.submit();
}