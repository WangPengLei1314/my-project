var arr=[1,2,3,4,5];
var evens=arr.filter(function(elem,i,arr){
  return elem%2==0
})
console.log(arr);
console.log(evens);