function calc(bonus1,bonus2,base=10000){
  //base=base!==undefined?base:10000;
  console.log("总工资是:"+(base+bonus1+bonus2));
}
calc(1000,2000);
calc(2000,3000,15000);
calc(6000,7000,0);