var arr=[12,23,3,123,2,1];
arr.sort((a,b)=>a-b);
console.log(arr);

var str="we two who and who!";
str=str.replace(/\b[a-z]/g,kw=>kw.toUpperCase());
console.log(str);

var arr=[1,2,3,4,5];
arr.forEach((elem,i,arr)=>arr[i]=elem*2)
console.log(arr);

(()=>{
  var start=new Date();
  console.log("开始加载网页内容, at:"+start);
})();

var lilei={
  sname:"Li Lei",
  sage:11,
  intr:function(){
    console.log("I'm "+this.sname+", I'm "+this.sage);
  }
}
lilei.intr();