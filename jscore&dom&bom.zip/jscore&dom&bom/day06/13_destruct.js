//作业: 使用参数结构封装ajax函数
function ajax({url,type,data,dataType}){
  console.log("*********调用ajax函数*********");
  //向url发送请求
  if(url!==undefined)
    console.log(`向${url}发送请求...`);
  //请求类型type:get/post
  if(type!==undefined)
    console.log(`以${type}方式发送...`);
  //参数data:
  if(data!==undefined)
    console.log(`携带参数${data}...`);
  //返回值的类型dataType: json
  if(dataType=="json")
    console.log("调用JSON.parse()转换json为对象");
}
ajax({
  url:"index.php",
  type:"get"
});
ajax({
  url:"search.php",
  type:"get",
  data:"kw=macbook"
});
ajax({
  url:"cart.php",
  type:"get",
  dataType:"json"
});
ajax({
  url:"search.php",
  type:"get",
  data:"kw=macbook",
  dataType:"json"
});