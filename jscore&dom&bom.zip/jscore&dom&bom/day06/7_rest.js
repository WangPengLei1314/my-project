function calc(base/*,...bonus*/){
  var bonus=[].slice.call(arguments,1);
          //arguments.slice(1);
  console.log("底薪:"+base);
  var sum=bonus.reduce(function(prev,elem){
    return prev+elem;
  });
  console.log("总奖金是:"+sum);
}
calc(10000,1000,2000);
calc(10000,1000,500,500,500);
calc(10000,2000);