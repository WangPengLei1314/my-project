var arr=[1,2,3,4,5];
var evens=arr.map(function(elem,i,arr){
  return elem*2;
})
console.log(arr);
console.log(evens);