console.log(Math.max(3,7,5));
var scores=[85,65,92,77];
//console.log(Math.max(...scores));
console.log(Math.max.apply(null,scores));
//console.log(Math.min(...scores));
console.log(Math.min.apply(null,scores));