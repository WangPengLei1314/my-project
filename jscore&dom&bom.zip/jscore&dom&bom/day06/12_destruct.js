var date=[2018,8,3];
     var [y   ,m,d]=date;
console.log(y,m,d);

var eric={ id:1001, ename:"埃里克", salary:12000}
      var {id,      ename,          salary }=eric;
console.log(id,ename,salary);
