var arr=[1,2,3,4,5];
arr.forEach(function(elem,i,arr){
  //elem*=2;//原数组元素不变
  arr[i]=elem*2;
  //arr[i]*=2;
})
console.log(arr);//2 4 6 8 10
var emps=[
  {id:1001,age:20},
  {id:1002,age:21},
  {id:1003,age:22},
  {id:1004,age:23},
];
emps.forEach(function(elem,i,arr){
  //elem:{id:xxxx, age:xx}
  elem.age+=1;//原数组元素被修改
})
console.log(emps);
