var price=12.5;
var count=5;
console.log(`
  单价: ¥${price.toFixed(2)}
  数量: ${count}
=========================
  小计: ¥${(price*count).toFixed(2)}
`);