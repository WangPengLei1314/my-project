var class1=[1,3,5,7,9];
var sum=class1.reduce(function(prev,elem){
  return prev+elem;
})
console.log(sum);
var class2=[2,4,6,8,10];
sum=class2.reduce(function(prev,elem){
  return prev+elem;
},sum);
console.log(sum);