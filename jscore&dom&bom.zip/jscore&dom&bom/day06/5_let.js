var t=0;//记录时间
function conn(){
  t+=0.3; console.log("建立连接，耗时0.3s");
}
function query(){
  //var t
  t+=0.8; console.log("查询数据，耗时0.8s");

  var err=false;
  if(err){//js中没有块级作用域，但let可将{}变为块级作用域
    //(function(){
      let t=new Date();
      console.log("出错啦！at:"+t.toLocaleString());
    //})()
  }
}

conn();
query();
console.log("共耗时"+t);

var a=10;
function fun(){
  //var a

  //console.log(a);//报错！
  let a=100;
  console.log(a);//100
}
fun();
console.log(a);//10

for(let i=1,sum=0;i<=100;sum+=i++);
console.log(sum);//报错！