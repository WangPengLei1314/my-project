var reg=/^\d{6}$/;

var input="123456a";
if(reg.test(input))
  console.log("验证通过!");
else
  console.log("密码格式不正确!");