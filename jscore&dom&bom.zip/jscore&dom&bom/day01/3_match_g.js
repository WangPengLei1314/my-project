var str="老师: 用小红 我的 朋友造句。小亮:小红是我的朋友。小东:朋友！小红是我的！";
var names=str.match(/小[\u4e00-\u9fa5]/g);
console.log(names);