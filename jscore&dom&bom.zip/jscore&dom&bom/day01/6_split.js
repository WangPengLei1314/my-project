var email="zhangdong@tedu.cn";
var arr=email.split("@");
var user=arr[0];
var domain=arr[1];
console.log(user,domain);

var html="<ul>    <li>85</li>       <li>92</li>      <li>78</li>       </ul>";
var scores=html.replace(/^<ul>\s*<li>/,"")
                .replace(/<\/li>\s*<\/ul>$/,"")
                .split(/<\/li>\s*<li>/i);
console.log(scores);
/*鄙视: 颠倒一个字符串的内容*/
var str="hello world!";
str=str.split("")
       .reverse()
       .join("");
console.log(str);