var str="no zuo no die, no can no bibi!";
str=str.replace("no","**");
console.log(str);
/*鄙视: 修改每个单词的首字母为大写！*/
var str="you can you up, no can no bibi!";
// /\b[a-z]/g
var reg=/\b[a-z]/g;
var arr=str.match(reg);
str=str.replace(reg,function(kw){
  return kw.toUpperCase();
});
console.log(str);
console.log("共替换"+arr.length+"处");

