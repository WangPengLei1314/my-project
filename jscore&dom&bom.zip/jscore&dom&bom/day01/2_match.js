var msg="wo cao！你家真大！";
//如果msg中包含国骂
var arr=msg.match(/([我卧]|wo)\s*([操艹槽草]|cao)/i);
//arr:[ "0":"我草", "index":0]
if(arr!=null)
  //就输出"包含敏感词，禁止发送"
                   //arr["index"]           arr["0"]
  console.log("在位置"+arr.index+"发现敏感词"+arr[0]+",不允许发送！");
else//否则
  console.log("成亮说:",msg);