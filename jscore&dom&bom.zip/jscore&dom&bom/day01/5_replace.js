//仅去掉开头的空字符
function ltrim(str){
  return str.replace(/^\s+/,"");
}
//仅去掉结尾的空字符
function rtrim(str){

}
//去掉开头和结尾的空字符
function trim(str){

}
console.log("|"+ltrim("  zhang dong   ")+"|");
//输出："|zhang dong   |"
console.log("|"+rtrim("  zhang dong   ")+"|");
//输出: "|  zhang dong|"
console.log("|"+trim("  zhang dong   ")+"|");
//输出: "|zhang dong|"