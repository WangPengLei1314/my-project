var msg="Wo cao！你家真大！";
//如果msg中包含国骂
//if(msg.indexOf("我草")!=-1)
if(msg.search(/([我卧]|wo)\s*([操艹槽草]|cao)/i)!=-1)
  //就输出"包含敏感词，禁止发送"
  console.log("包含敏感词，禁止发送！");
else//否则
  console.log("成亮说:",msg);