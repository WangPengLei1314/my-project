var names=["小红"];//从服务器端


var str="老师: 用小红 我的 朋友造句。小亮:小红是我的朋友。小东:朋友！小红是我的！";
var reg=// /names.join("|")/g 错误
        new RegExp(names.join("|"),"g");
var arr=str.match(reg);
console.log(arr);
